# Matchmaking edge-case JSON files

These files use the schema expected by `server/cmd/matchmake/main.go`:

- player_id
- name
- kills
- deaths
- flag_captures
- wins
- losses
- join_offset_seconds

For clarity, deaths/flags/wins/losses are set to 0 in these edge cases, so the computed skill equals the kills value.

Files:
1. players_edge_balanced_many_matches.json - many balanced players with duplicate/equal skills; tests tie handling and low quality matches.
2. players_edge_relaxation_threshold.json - tests relaxation behavior where gap 55 is invalid normally but valid after waiting long enough.
3. players_edge_no_valid_pairs.json - tests no-match behavior when all players are young and all gaps exceed U_max.
4. players_edge_odd_leftover_after_match.json - tests one valid match plus one leftover solo player.

To run one file, copy it into `server/cmd/matchmake/` and change the inputPath in `main.go`, for example:

inputPath := filepath.Join(baseDir, "players_edge_relaxation_threshold.json")

Then run the matchmake command and inspect `report.txt`.
